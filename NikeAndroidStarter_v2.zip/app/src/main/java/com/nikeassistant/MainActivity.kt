package com.nikeassistant

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray

data class TaskItem(val id: Long, val title: String, val done: Boolean = false)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NikeApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NikeApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("nike_data", Activity.MODE_PRIVATE) }

    fun loadTasks(): List<TaskItem> {
        val raw = prefs.getString("tasks", "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val obj = arr.getJSONObject(i)
                TaskItem(obj.getLong("id"), obj.getString("title"), obj.optBoolean("done", false))
            }
        } catch (_: Exception) { emptyList() }
    }
    var tasks by remember { mutableStateOf(loadTasks()) }
    var taskText by remember { mutableStateOf("") }
    var command by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("מוכן לפעולה. בחר קיצור דרך או כתוב פקודה.") }

    fun saveTasks(list: List<TaskItem>) {
        val arr = JSONArray()
        list.forEach { item ->
            arr.put(org.json.JSONObject().put("id", item.id).put("title", item.title).put("done", item.done))
        }
        prefs.edit().putString("tasks", arr.toString()).apply()
    }
    fun openApp(packageName: String, fallbackUrl: String? = null) {
        val launch = context.packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            context.startActivity(launch)
            status = "פתחתי את האפליקציה."
        } else if (fallbackUrl != null) {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(fallbackUrl)))
            status = "האפליקציה לא נמצאה; פתחתי את האתר."
        } else {
            status = "האפליקציה לא נמצאה במכשיר."
        }
    }
    fun runCommand(raw: String) {
        val q = raw.trim().lowercase()
        when {
            q.contains("וואטסאפ") || q.contains("whatsapp") -> openApp("com.whatsapp", "https://web.whatsapp.com")
            q.contains("יוטיוב") || q.contains("youtube") -> openApp("com.google.android.youtube", "https://youtube.com")
            q.contains("הגדרות") -> context.startActivity(Intent(Settings.ACTION_SETTINGS))
            q.contains("קבצים") || q.contains("פלייבק") || q.contains("מוזיקה") ->
                context.startActivity(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE))
            q.contains("משימה") -> {
                val title = raw.substringAfter("משימה", "").trim().removePrefix(":")
                if (title.isNotBlank()) {
                    val next = tasks + TaskItem(System.currentTimeMillis(), title)
                    tasks = next; saveTasks(next); status = "הוספתי משימה: $title"
                } else status = "כתוב למשל: משימה לסדר פלייבקים"
            }
            q.contains("סונו") || q.contains("suno") -> {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://suno.com")))
                status = "פתחתי את Suno בדפדפן."
            }
            else -> status = "עדיין לא למדתי את הפקודה הזאת. נסה: פתח WhatsApp, פתח YouTube, קבצים, הגדרות, או משימה לסדר פלייבקים."
        }
    }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) status = "נבחר קובץ. אפשר לפתוח או לשתף אותו מתוך האפליקציה שמנהלת את הקובץ."
    }
    val voiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                command = spoken
                runCommand(spoken)
            }
        }
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Nike", fontWeight = FontWeight.Bold)
                            Text("העוזר האישי שלך · גרסה 0.2", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                )
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Card(shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("היי! אני Nike 👋", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Text("אני יכול לפתוח אפליקציות, לעזור למצוא קבצים, ולשמור לך רשימת משימות גם אחרי שסוגרים את האפליקציה.")
                            Text(status, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
                item { Text("פקודה מהירה", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
                item {
                    OutlinedTextField(
                        value = command,
                        onValueChange = { command = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("מה Nike יעשה?") },
                        placeholder = { Text("למשל: פתח WhatsApp") },
                        trailingIcon = {
                            IconButton(onClick = {
                                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "he-IL")
                                    .putExtra(RecognizerIntent.EXTRA_PROMPT, "מה תרצה ש-Nike יעשה?")
                                try { voiceLauncher.launch(intent) }
                                catch (_: Exception) { status = "זיהוי קולי לא זמין במכשיר כרגע." }
                            }) { Icon(Icons.Default.Mic, contentDescription = "פקודה קולית") }
                        }
                    )
                    Button(onClick = { runCommand(command) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Bolt, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("בצע פקודה")
                    }
                }
                item { Text("קיצורי דרך", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Button(onClick = { openApp("com.whatsapp", "https://web.whatsapp.com") }, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.Chat, contentDescription = null); Spacer(Modifier.width(5.dp)); Text("WhatsApp")
                            }
                            OutlinedButton(onClick = { openApp("com.google.android.youtube", "https://youtube.com") }, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.PlayCircle, contentDescription = null); Spacer(Modifier.width(5.dp)); Text("YouTube")
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(onClick = {
                                filePicker.launch(arrayOf("*/*"))
                                status = "בחר קובץ דרך בורר הקבצים של Android."
                            }, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.FolderOpen, contentDescription = null); Spacer(Modifier.width(5.dp)); Text("בחירת קובץ")
                            }
                            OutlinedButton(onClick = {
                                context.startActivity(Intent(Settings.ACTION_SETTINGS))
                            }, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.Settings, contentDescription = null); Spacer(Modifier.width(5.dp)); Text("הגדרות")
                            }
                        }
                        OutlinedButton(onClick = {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://suno.com")))
                        }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.MusicNote, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("פתח Suno")
                        }
                    }
                }
                item { Text("המשימות שלי", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = taskText,
                            onValueChange = { taskText = it },
                            label = { Text("משימה חדשה") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        IconButton(onClick = {
                            val title = taskText.trim()
                            if (title.isNotEmpty()) {
                                val next = tasks + TaskItem(System.currentTimeMillis(), title)
                                tasks = next; saveTasks(next); taskText = ""
                                status = "המשימה נשמרה."
                            }
                        }) { Icon(Icons.Default.AddCircle, contentDescription = "הוסף משימה") }
                    }
                }
                items(tasks, key = { it.id }) { item ->
                    Card {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = item.done, onCheckedChange = { checked ->
                                val next = tasks.map { if (it.id == item.id) it.copy(done = checked) else it }
                                tasks = next; saveTasks(next)
                            })
                            Text(item.title, modifier = Modifier.weight(1f))
                            IconButton(onClick = {
                                val next = tasks.filterNot { it.id == item.id }
                                tasks = next; saveTasks(next)
                            }) { Icon(Icons.Default.DeleteOutline, contentDescription = "מחק משימה") }
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("מה עדיין מוגבל?", fontWeight = FontWeight.Bold)
                            Text("Nike לא יכול לשלוט בחופשיות בכל אפליקציה או לשלוח הודעות בעצמו בגרסה הזאת. Android דורש הרשאות ואישורים לפעולות רגישות. כרגע הפקודות פועלות לפי רשימה מוגדרת, והמשימות נשמרות במכשיר.")
                        }
                    }
                }
            }
        }
    }
}
